# PeakLegacy Client

**PeakLegacy** es un cliente optimizado para **Eaglercraft 1.8.9** (y futura 1.12.2), diseñado para **Chromebook y PCs de baja potencia**, con un estilo galáctico y funcionalidades pensadas para launcher.

---

## ⚠️ Advertencias

- Este cliente está en **desarrollo**. Algunas funciones pueden fallar.  
- Requiere **Java 8+**.  
- Uso **educativo/personal** solamente.  
- La versión 1.12.2 aún no está disponible; el botón aparece deshabilitado en la web.  
- Algunos archivos (`.jar`) de prueba pueden estar vacíos hasta la publicación de la versión oficial.

---

## 🗂 Estructura del proyecto

La estructura de carpetas y archivos recomendada para que la web funcione correctamente es:Usarla Correctamente